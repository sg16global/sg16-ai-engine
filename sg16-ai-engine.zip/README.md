# SG16 AI Engine

Five shields in one secure application:
1. **AI Chat Hub** — General intelligence, deep reasoning, research synthesis, multimodal document & image analysis.
2. **Coding Hub** — Real-time security, AST parsing, and 10-tool scanning (Semgrep, ESLint, SonarJS, Gitleaks, Retire.js, Acorn, Esprima, Istanbul NYC, npm audit, and TypeScript).
3. **Health Shield** — Clinical and wellness symptom triage, emergency disclaimers, and vital guidance.
4. **Student Shield** — Academic coaching, homework verification, and concept breakdowns.
5. **Market Shield** — Macro asset analysis, market volatility metrics, and strategic risk controls.

## Tech Stack

- **Framework**: React 18 SPA + Vite
- **Styling**: Tailwind CSS with SG16 Pro Geo HUD theme
- **State Management**: Zustand
- **Icons**: Lucide React
- **Document Processing**: PDF.js

## Getting Started

```bash
npm install
npm run dev
```

Build for production:
```bash
npm run build
```
