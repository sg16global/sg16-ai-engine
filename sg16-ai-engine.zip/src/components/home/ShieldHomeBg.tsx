/**
 * Shield Home Background
 * Clean display of the Earth-DNA cosmic background with no color wash or artificial overlays.
 */
export function ShieldHomeBg() {
  return (
    <div className="shield-home__earth-bg" aria-hidden />
  );
}
