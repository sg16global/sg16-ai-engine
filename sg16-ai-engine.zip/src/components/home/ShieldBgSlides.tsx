/**
 * Shield Background Slides
 * Clean ambient Neon Black × Neon Pink glow for workspaces.
 * Legacy multi-slide cycle and double-layered background loop permanently removed.
 */
export function ShieldBgSlides({ className = '' }: { className?: string }) {
  return (
    <div className={`sg16-workspace-ambient-bg pointer-events-none absolute inset-0 z-0 overflow-hidden ${className}`.trim()} aria-hidden>
      {/* Subtle top-center neon pink radial spotlight */}
      <div className="absolute -top-[12%] left-1/2 -translate-x-1/2 w-[72vw] h-[480px] rounded-full bg-[radial-gradient(ellipse_at_center,rgba(255,22,141,0.08)_0%,transparent_65%)] blur-2xl pointer-events-none" />
      {/* Subtle bottom-right aura */}
      <div className="absolute -bottom-[10%] right-[5%] w-[45vw] h-[350px] rounded-full bg-[radial-gradient(ellipse_at_center,rgba(255,22,141,0.04)_0%,transparent_70%)] blur-3xl pointer-events-none" />
    </div>
  );
}
