import { useEffect, useRef, useState } from 'react';
import {
  getGoogleOriginSetupHint,
  initGoogleIdentity,
  loadGsiScript,
  renderGoogleSignInButton,
  resolveGoogleClientId,
  validateGoogleAuthEnvironment,
} from '../../lib/googleIdentity';
import { getPageOrigin } from '../../config/googleAuth';

interface GoogleSignInButtonProps {
  onCredential: (credential: string) => void;
  onError: (message: string) => void;
  onReady?: () => void;
  disabled?: boolean;
  silent?: boolean;
  buttonWidth?: number;
}

/** Stable GIS button — initialize() runs once per page, button stays mounted. */
export function GoogleSignInButton({
  onCredential,
  onError,
  onReady,
  disabled,
  silent = false,
  buttonWidth = 280,
}: GoogleSignInButtonProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const onCredentialRef = useRef(onCredential);
  const onReadyRef = useRef(onReady);
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading');

  onCredentialRef.current = onCredential;
  onReadyRef.current = onReady;

  useEffect(() => {
    let cancelled = false;

    (async () => {
      try {
        const clientId = await resolveGoogleClientId();
        if (cancelled) return;

        const envError = validateGoogleAuthEnvironment(clientId);
        if (envError) {
          setStatus('error');
          onError(envError);
          return;
        }

        await loadGsiScript(clientId);
        if (cancelled || !containerRef.current) return;

        initGoogleIdentity(clientId, (credential) => onCredentialRef.current(credential));
        renderGoogleSignInButton(containerRef.current, { width: buttonWidth });
        setStatus('ready');
        onReadyRef.current?.();
      } catch (err) {
        if (cancelled) return;
        setStatus('error');
        onError(err instanceof Error ? err.message : 'Google sign-in failed to initialize');
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [buttonWidth, onError]);

  return (
    <div
      className={`min-h-[44px] flex flex-col items-center justify-center gap-2 ${disabled ? 'opacity-50 pointer-events-none' : ''}`}
    >
      {status === 'loading' && !silent && (
        <p className="text-xs text-gray-400 animate-pulse">Loading Google sign-in…</p>
      )}
      <div ref={containerRef} className={status === 'ready' ? '' : 'sr-only'} aria-hidden={status !== 'ready'} />
    </div>
  );
}
