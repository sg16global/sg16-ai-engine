type LandingBrandLogoProps = {
  className?: string;
  compact?: boolean;
};

/**
 * SG16 Cyber Brand Logo
 * Monogram badge in Neon Pink × Obsidian with clean typography.
 */
export function LandingBrandLogo({ className = '', compact = false }: LandingBrandLogoProps) {
  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`.trim()}>
      <div className="relative flex items-center justify-center h-9 sm:h-10 px-2.5 rounded-lg bg-gradient-to-br from-[#FF168D]/30 via-[#191321] to-[#0A0A12] border border-[#FF168D]/50 shadow-[0_0_18px_rgba(255,22,141,0.35)]">
        <span className="font-black italic tracking-tighter text-xl sm:text-2xl bg-gradient-to-r from-white via-[#FF5CB8] to-[#FF168D] bg-clip-text text-transparent font-['Orbitron',sans-serif]">
          ST6
        </span>
      </div>
      <span className="text-base sm:text-lg font-bold tracking-tight text-white font-['Orbitron',sans-serif]">
        SG16 <span className="text-[#FF5CB8]">AI Engine</span>
      </span>
    </div>
  );
}
