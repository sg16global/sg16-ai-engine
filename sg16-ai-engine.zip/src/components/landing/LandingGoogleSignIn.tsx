import { useEffect, useState } from 'react';
import { CheckCircle2, Zap } from 'lucide-react';
import { useAppStore } from '../../core/appState';
import { isValidGoogleClientId, resolveGoogleClientId } from '../../lib/googleIdentity';

function GoogleGIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-5 w-5 shrink-0" aria-hidden>
      <path
        fill="#4285F4"
        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
      />
      <path
        fill="#34A853"
        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
      />
      <path
        fill="#FBBC05"
        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
      />
      <path
        fill="#EA4335"
        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
      />
    </svg>
  );
}

interface LandingGoogleSignInProps {
  compact?: boolean;
}

export function LandingGoogleSignIn({ compact = false }: LandingGoogleSignInProps) {
  const openLoginModal = useAppStore((s) => s.openLoginModal);
  const enterLocalPreview = useAppStore((s) => s.enterLocalPreview);
  const [hasClientId, setHasClientId] = useState<boolean | null>(null);

  useEffect(() => {
    void resolveGoogleClientId().then((id) => {
      setHasClientId(isValidGoogleClientId(id));
    });
  }, []);

  const handleClick = () => {
    if (hasClientId) {
      openLoginModal();
    } else {
      void enterLocalPreview();
    }
  };

  return (
    <div className={`flex flex-col items-center ${compact ? 'gap-3 w-full' : 'gap-4 w-full max-w-[400px] mx-auto'}`}>
      <button
        type="button"
        onClick={handleClick}
        className="flex w-full items-center justify-center gap-3 rounded-full border border-[#ff7a00]/60 bg-[#0d0703]/90 px-6 py-3.5 text-[15px] font-semibold text-white shadow-[0_0_28px_rgba(255,122,0,0.25)] transition hover:border-[#ff9500] hover:shadow-[0_0_36px_rgba(255,122,0,0.42)]"
      >
        <GoogleGIcon />
        <span>Continue to SG16 Workspace</span>
      </button>

      <div className="flex flex-wrap items-center justify-center gap-4 text-[11px] text-[#ffa34d]/90 sm:gap-5 sm:text-xs">
        <span className="inline-flex items-center gap-1.5">
          <CheckCircle2 className="h-3.5 w-3.5 text-[#ff7a00]" />
          Instant Access
        </span>
        <span className="inline-flex items-center gap-1.5">
          <Zap className="h-3.5 w-3.5 text-[#ff7a00]" />
          All Workspaces Ready
        </span>
      </div>
    </div>
  );
}
