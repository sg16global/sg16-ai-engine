/**
 * Landing Cyber Ambient Background
 * Pure Deep Black × Neon Pink cyber portal backdrop matching reference dashboard.
 * Eliminates legacy duplicate background video loops to prevent double-layered glitches.
 */
export function LandingVideoBg() {
  return (
    <div className="landing-cyber-bg pointer-events-none fixed inset-0 z-0 overflow-hidden bg-[#050509]" aria-hidden>
      {/* Top ambient neon pink bloom */}
      <div className="absolute -top-[10%] left-1/2 -translate-x-1/2 w-[900px] max-w-[90vw] h-[550px] rounded-full bg-[radial-gradient(ellipse_at_center,rgba(255,22,141,0.12)_0%,rgba(185,22,105,0.04)_45%,transparent_70%)] blur-3xl" />
      
      {/* Central Cyber Portal Arch Ring (behind hero card) */}
      <div className="absolute top-[80px] sm:top-[100px] left-1/2 -translate-x-1/2 w-[720px] max-w-[85vw] h-[720px] max-h-[85vw] pointer-events-none">
        {/* Outer glowing halo ring */}
        <div className="absolute inset-0 rounded-full border border-[#FF168D]/30 shadow-[0_0_60px_rgba(255,22,141,0.25)]" />
        <div className="absolute inset-4 rounded-full border border-[#FF3DA5]/20 shadow-[inset_0_0_40px_rgba(255,22,141,0.15)]" />
        {/* Soft pink core radial glow */}
        <div className="absolute inset-10 rounded-full bg-[radial-gradient(circle_at_center,rgba(255,22,141,0.16)_0%,rgba(25,19,33,0.3)_60%,transparent_75%)] blur-xl" />
      </div>

      {/* Cyber Dais / Pedestal Rings at bottom of hero */}
      <div className="absolute top-[370px] sm:top-[410px] left-1/2 -translate-x-1/2 w-[960px] max-w-[96vw] h-[180px] pointer-events-none">
        {/* Tier 1 Dais Ring */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[760px] max-w-[90vw] h-[100px] rounded-[50%] border-t-2 border-[#FF168D] bg-gradient-to-b from-[#191321]/80 to-transparent shadow-[0_-4px_28px_rgba(255,22,141,0.6)]" />
        {/* Tier 2 Dais Ring */}
        <div className="absolute top-7 left-1/2 -translate-x-1/2 w-[860px] max-w-[95vw] h-[110px] rounded-[50%] border-t-2 border-[#FF3DA5]/80 bg-gradient-to-b from-[#12121D]/70 to-transparent shadow-[0_-2px_22px_rgba(255,22,141,0.4)]" />
        {/* Base Glow Stage */}
        <div className="absolute top-14 left-1/2 -translate-x-1/2 w-[940px] max-w-[98vw] h-[120px] rounded-[50%] border-t border-[#FF5CB8]/40 bg-gradient-to-b from-[#0A0A12]/90 to-transparent" />
      </div>

      {/* Subtle corner grid and laser grading */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,rgba(255,22,141,0.06)_0%,transparent_60%)]" />
    </div>
  );
}

export const LANDING_LOGO = '/landing/sg16-hero-logo.png';
