import { useState, useEffect } from 'react';
import { ArrowUpRight, Globe2, BarChart3, MapPin } from 'lucide-react';
import './landingNetworkCards.css';

const GEO_URL = 'https://saifglobal16.info';
const FINANCE_URL = 'https://sg16finance.com';

const THREAT_LOCATIONS = [
  { city: 'Malacca, Malaysia', status: 'Normal' },
  { city: 'US - New York', status: 'Normal' },
  { city: 'UK - London', status: 'Normal' },
  { city: 'DE - Frankfurt', status: 'Normal' },
  { city: 'JP - Tokyo', status: 'Normal' },
  { city: 'KR - Seoul', status: 'Normal' },
];

const FINANCE_ITEMS = [
  { sym: 'BTC', price: '97,420', change: '+0.82%' },
  { sym: 'ETH', price: '3,145', change: '+1.21%' },
  { sym: 'GOLD', price: '2,628', change: '+0.56%' },
  { sym: 'S&P 500', price: '5,762', change: '+0.47%' },
  { sym: 'NASDAQ', price: '18,341', change: '+0.73%' },
];

export function LandingNetworkCards() {
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true });

  return (
    <div className="landing-network-cards hidden xl:block" aria-label="SG16 live intelligence platforms">
      {/* Geo Monitor (Left Card) */}
      <div className="landing-network-card landing-network-card--left">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#191321] border border-[#FF168D]/40 text-[#FF168D] shadow-[0_0_12px_rgba(255,22,141,0.25)]">
              <Globe2 className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1 rounded-full bg-[#FF168D]/15 border border-[#FF168D]/40 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#FF5CB8]">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#FF168D] animate-ping" />
                  Live
                </span>
              </div>
              <h3 className="mt-1 text-sm font-bold text-white tracking-wide">Geo Monitor</h3>
            </div>
          </div>
          <button
            type="button"
            onClick={() => window.open(GEO_URL, '_blank', 'noopener,noreferrer')}
            className="text-white/40 hover:text-[#FF168D] transition"
            aria-label="Open Geo Monitor"
          >
            <ArrowUpRight className="h-4 w-4" />
          </button>
        </div>

        <p className="mt-1.5 text-[11px] text-white/50">Global traffic &amp; threat monitoring</p>
        <p className="mt-2 text-[10px] font-mono text-white/40 border-b border-[#29202F] pb-2">
          Live view — {timeStr}
        </p>

        {/* Location monitoring status */}
        <div className="mt-3 space-y-1.5 font-mono text-[11px]">
          {THREAT_LOCATIONS.map((loc) => (
            <div key={loc.city} className="flex items-center justify-between text-white/75">
              <span className="flex items-center gap-1.5 truncate">
                <MapPin className="h-3 w-3 text-[#FF168D] shrink-0" />
                <span className="truncate">{loc.city}</span>
              </span>
              <span className="text-[#38D9A9] text-[10px] font-semibold shrink-0">— {loc.status}</span>
            </div>
          ))}
        </div>

        {/* Dotted World Map Graphic */}
        <div className="mt-3 relative h-16 w-full opacity-60 rounded-lg overflow-hidden flex items-center justify-center bg-black/30 border border-[#29202F]/60">
          <svg className="w-full h-full text-[#FF168D]/40" viewBox="0 0 200 80" fill="currentColor">
            <circle cx="20" cy="25" r="1.5" />
            <circle cx="30" cy="28" r="1.2" />
            <circle cx="45" cy="35" r="1.5" />
            <circle cx="50" cy="45" r="1.8" />
            <circle cx="65" cy="55" r="1.2" />
            <circle cx="95" cy="20" r="1.8" />
            <circle cx="105" cy="25" r="1.5" />
            <circle cx="115" cy="30" r="1.2" />
            <circle cx="140" cy="22" r="1.8" />
            <circle cx="150" cy="35" r="2.0" />
            <circle cx="160" cy="40" r="1.5" />
            <circle cx="170" cy="60" r="1.8" />
            <circle cx="120" cy="55" r="1.5" />
            <circle cx="130" cy="65" r="1.2" />
            <circle cx="100" cy="45" r="1.5" />
          </svg>
          <span className="absolute bottom-1 right-2 text-[9px] text-[#FF5CB8]/70 font-mono">MAP ACTIVE</span>
        </div>

        <a
          href={GEO_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-3 block text-center text-[11px] font-bold uppercase tracking-wider text-[#FF168D] hover:text-[#FF3DA5] transition"
        >
          Open Live Site →
        </a>
      </div>

      {/* SG16 Finance (Right Card) */}
      <div className="landing-network-card landing-network-card--right">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#191321] border border-[#FF168D]/40 text-[#FF168D] shadow-[0_0_12px_rgba(255,22,141,0.25)]">
              <BarChart3 className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-wide">SG16 Finance</h3>
              <p className="text-[11px] text-white/50">Market intelligence &amp; data</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => window.open(FINANCE_URL, '_blank', 'noopener,noreferrer')}
            className="text-white/40 hover:text-[#FF168D] transition"
            aria-label="Open SG16 Finance"
          >
            <ArrowUpRight className="h-4 w-4" />
          </button>
        </div>

        <p className="mt-3 text-[10px] font-mono text-white/40 border-b border-[#29202F] pb-2">
          Market Live
        </p>

        {/* Finance ticker rows matching screenshot */}
        <div className="mt-3 space-y-2 font-mono text-[12px]">
          {FINANCE_ITEMS.map((item) => (
            <div key={item.sym} className="flex items-center justify-between">
              <span className="font-semibold text-white/90">{item.sym}</span>
              <span className="text-white/70">{item.price}</span>
              <span className="text-[#38D9A9] font-bold text-[11px]">{item.change}</span>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-3 border-t border-[#29202F]">
          <a
            href={FINANCE_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="block text-center text-[11px] font-bold uppercase tracking-wider text-[#FF168D] hover:text-[#FF3DA5] transition"
          >
            Open Live Site →
          </a>
        </div>
      </div>
    </div>
  );
}
