import { useState } from 'react';
import { LandingBrandLogo } from './LandingBrandLogo';
import { SG16_BRAND } from '../../core/branding';
import { CompanyCertificateModal } from '../company/CompanyCertificateModal';
import { ShieldCheck, FileCheck } from 'lucide-react';

export function SiteFooter() {
  const [certModalOpen, setCertModalOpen] = useState(false);

  return (
    <footer className="landing-footer">
      <div className="landing-shell">
        <LandingBrandLogo compact className="landing-footer-logo mx-auto mb-4 opacity-90" />
        <p className="mx-auto mb-2 max-w-xl text-center text-[12px] font-semibold uppercase tracking-[0.12em] text-[#ff8a8a]">
          {SG16_BRAND.engineType} · {SG16_BRAND.company}
        </p>
        <p className="mx-auto mb-3 max-w-xl text-center text-[11px] text-white/70">
          State of New Mexico · Filing ID: <span className="font-mono font-bold text-white">#{SG16_BRAND.businessId}</span> · {SG16_BRAND.entityType}
        </p>

        <div className="flex justify-center mb-4">
          <button
            type="button"
            onClick={() => setCertModalOpen(true)}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#ff173d]/15 hover:bg-[#ff173d]/25 border border-[#ff173d]/40 text-[#ff8a8a] hover:text-white text-[11px] font-semibold transition shadow-sm"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <FileCheck className="w-3.5 h-3.5" />
            <span>Official Certificate of Organization (Verified Record)</span>
          </button>
        </div>

        <p className="mx-auto mb-4 max-w-md text-center text-[11px] leading-relaxed text-white/40">
          Zero-Data Trace: chat content is processed in real time and not stored on our servers. History stays on
          your device. SG16 Secure Room on {SG16_BRAND.publicUrl.replace('https://', '')}.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-[12px] text-white/45">
          <a href="/help" className="hover:text-[#ff173d] transition">
            Help
          </a>
          <a href="/license" className="hover:text-[#ff173d] transition">
            License & Entity
          </a>
          <a href="/privacy" className="hover:text-[#ff173d] transition">
            Privacy
          </a>
          <a href="/terms" className="hover:text-[#ff173d] transition">
            Terms
          </a>
          <a href="/contact" className="hover:text-[#ff173d] transition">
            Contact
          </a>
          <a href={`mailto:${SG16_BRAND.contactEmail}`} className="hover:text-[#ff173d] transition">
            {SG16_BRAND.contactEmail}
          </a>
        </div>

        <p className="mt-3 text-center text-[11px] text-white/35">
          © {new Date().getFullYear()} {SG16_BRAND.company}. {SG16_BRAND.registeredAddress}. All rights reserved.
        </p>
      </div>

      <CompanyCertificateModal isOpen={certModalOpen} onClose={() => setCertModalOpen(false)} />
    </footer>
  );
}
