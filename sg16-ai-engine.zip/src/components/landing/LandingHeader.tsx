import { useState } from 'react';
import {
  Lock,
  Menu,
  Rocket,
  X,
  Home,
  Sparkles,
  CreditCard,
  ShieldCheck,
  HelpCircle,
  Mail,
  Award,
} from 'lucide-react';
import { useAppStore } from '../../core/appState';
import { pushAppPath } from '../../core/routes';
import { LandingBrandLogo } from './LandingBrandLogo';

const NAV_LINKS = [
  { id: 'home', label: 'Home', href: '/', icon: Home },
  { id: 'features', label: 'Features', href: '#features', icon: Sparkles },
  { id: 'pricing', label: 'Pricing', href: '/pricing', icon: CreditCard },
  { id: 'certificate', label: 'Entity License', href: '/license', icon: ShieldCheck },
  { id: 'help', label: 'Help', href: '/help', icon: HelpCircle },
  { id: 'about', label: 'Contact', href: '/contact', icon: Mail },
] as const;

function BrandMark() {
  return <LandingBrandLogo compact />;
}

interface LandingHeaderProps {
  onOpenMemorial?: () => void;
}

export function LandingHeader({ onOpenMemorial }: LandingHeaderProps) {
  const openLoginModal = useAppStore((s) => s.openLoginModal);
  const enterGuestTour = useAppStore((s) => s.enterGuestTour);
  const openStaging = useAppStore((s) => s.openStaging);
  const [menuOpen, setMenuOpen] = useState(false);

  const onNav = (href: string) => {
    setMenuOpen(false);
    if (href.startsWith('#')) {
      document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
      return;
    }
    if (href === '/') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    pushAppPath(href);
  };

  return (
    <header className="landing-header sticky top-0 z-50 min-h-[70px] border-b border-[#29202F] bg-[#050509]/90 backdrop-blur-xl">
      <div className="mx-auto flex min-h-[70px] max-w-[1360px] items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <button type="button" onClick={() => onNav('/')} className="shrink-0 transition-opacity hover:opacity-90">
          <BrandMark />
        </button>

        <nav className="hidden flex-1 items-center justify-center gap-6 lg:flex">
          {NAV_LINKS.map((link) => {
            const Icon = link.icon;
            const isHome = link.id === 'home';
            return (
              <button
                key={link.id}
                type="button"
                onClick={() => onNav(link.href)}
                className={`relative flex items-center gap-1.5 py-2 text-[14px] font-medium transition ${
                  isHome ? 'text-[#FF168D] font-semibold' : 'text-white/70 hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 ${isHome ? 'text-[#FF168D]' : 'text-white/50'}`} />
                <span>{link.label}</span>
                {isHome && (
                  <span className="absolute bottom-0 left-0 right-0 h-[2px] rounded-full bg-[#FF168D] shadow-[0_0_8px_#FF168D]" />
                )}
              </button>
            );
          })}
          {onOpenMemorial && (
            <button
              type="button"
              onClick={onOpenMemorial}
              className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-[#FF5CB8] hover:text-white transition px-2.5 py-1 rounded-lg bg-[#FF168D]/10 border border-[#FF168D]/30 hover:bg-[#FF168D]/20"
            >
              <Award className="w-3.5 h-3.5 text-[#FF168D]" />
              <span>AI Pioneers</span>
            </button>
          )}
        </nav>

        <div className="flex items-center gap-2 sm:gap-3">
          <button
            type="button"
            onClick={() => openStaging()}
            className="inline-flex items-center gap-2 rounded-lg border border-[#29202F] bg-[#0A0A12] px-3.5 py-2 text-[13px] font-medium text-white transition hover:border-[#60304F] hover:bg-[#12121D] shadow-sm"
            title="Open Next-Gen Staging & 24/7 AI Support"
          >
            <span className="w-2 h-2 rounded-full bg-[#38D9A9] animate-pulse shrink-0 shadow-[0_0_8px_#38D9A9]" />
            <span className="hidden sm:inline">Staging Lab</span>
            <span className="text-[10px] text-[#FFB547] font-mono">24/7 AI</span>
          </button>
          <button
            type="button"
            onClick={() => openLoginModal()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#29202F] bg-[#0A0A12] px-3.5 py-2 text-[13px] font-medium text-white/90 transition hover:border-[#60304F] hover:bg-[#12121D]"
          >
            <Lock className="h-3.5 w-3.5 text-[#FF168D]" />
            <span>Login</span>
          </button>
          <button
            type="button"
            onClick={() => enterGuestTour()}
            className="hidden items-center gap-1.5 rounded-lg bg-[#FF168D] hover:bg-[#FF3DA5] px-4 py-[9px] text-[13px] font-bold text-[#09060B] transition shadow-[0_0_20px_rgba(255,22,141,0.4)] sm:inline-flex"
          >
            <Rocket className="h-4 w-4" />
            <span>Start Tour</span>
          </button>
          <button
            type="button"
            className="flex h-10 w-10 items-center justify-center rounded-lg border border-[#29202F] bg-[#0A0A12] text-white/90 hover:border-[#60304F] hover:bg-[#12121D] lg:hidden"
            onClick={() => setMenuOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className="fixed inset-0 z-[300] lg:hidden">
          <div
            className="fixed inset-0 bg-black/85 backdrop-blur-md"
            onClick={() => setMenuOpen(false)}
            aria-hidden
          />
          <div className="fixed top-0 right-0 bottom-0 w-full max-w-xs border-l border-[#29202F] bg-[#050509] p-6 shadow-2xl flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-8 pb-4 border-b border-[#29202F]">
                <BrandMark />
                <button
                  type="button"
                  onClick={() => setMenuOpen(false)}
                  className="p-2 text-white/70 hover:text-white"
                  aria-label="Close menu"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="space-y-2">
                {NAV_LINKS.map((link) => {
                  const Icon = link.icon;
                  const isHome = link.id === 'home';
                  return (
                    <button
                      key={link.id}
                      type="button"
                      onClick={() => onNav(link.href)}
                      className={`flex w-full items-center gap-3 py-2.5 px-3 rounded-lg text-sm font-medium transition ${
                        isHome
                          ? 'bg-[#191321] text-[#FF168D] border border-[#FF168D]/40'
                          : 'text-white/80 hover:text-white hover:bg-[#0A0A12]'
                      }`}
                    >
                      <Icon className={`w-4 h-4 ${isHome ? 'text-[#FF168D]' : 'text-white/50'}`} />
                      <span>{link.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-6 border-t border-[#29202F] space-y-3">
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  enterGuestTour();
                }}
                className="w-full flex items-center justify-center gap-2 rounded-lg bg-[#FF168D] hover:bg-[#FF3DA5] py-3 text-sm font-bold text-[#09060B] shadow-[0_0_18px_rgba(255,22,141,0.4)]"
              >
                <Rocket className="w-4 h-4" />
                <span>Start Tour</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  openLoginModal();
                }}
                className="w-full flex items-center justify-center gap-2 rounded-lg border border-[#29202F] bg-[#0A0A12] py-2.5 text-sm font-medium text-white hover:border-[#60304F]"
              >
                <Lock className="w-4 h-4 text-[#FF168D]" />
                <span>Login</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
