import {
  MessageSquare,
  Code2,
  HeartPulse,
  GraduationCap,
  TrendingUp,
  Shield,
  Rocket,
  ChevronRight,
  Globe,
  Sparkles,
} from 'lucide-react';
import { useAppStore } from '../../core/appState';
import { LandingHeader } from './LandingHeader';
import { LandingVideoBg } from './LandingVideoBg';
import { LandingNetworkCards } from './LandingNetworkCards';
import type { WorkspaceType } from '../../core/types';
import './landingStyles.css';

const SHIELDS_DATA = [
  {
    id: 'general' as WorkspaceType,
    icon: MessageSquare,
    title: 'AI Chat',
    desc: 'Smart, private and sovereign conversations.',
  },
  {
    id: 'coding' as WorkspaceType,
    icon: Code2,
    title: 'Coding Hub',
    desc: 'Build, debug and deploy with AI assistance.',
  },
  {
    id: 'health' as WorkspaceType,
    icon: HeartPulse,
    title: 'Health',
    desc: 'Smarter health insights for a better you.',
  },
  {
    id: 'student-shield' as WorkspaceType,
    icon: GraduationCap,
    title: 'Student',
    desc: 'Learn, create and grow with AI.',
  },
  {
    id: 'market' as WorkspaceType,
    icon: TrendingUp,
    title: 'Market',
    desc: 'Real-time data and financial intelligence.',
  },
];

const LATEST_ACTIVITIES = [
  { title: 'SG16 Engine', detail: 'New update released', time: '2h ago', icon: Shield },
  { title: 'SG16 Finance', detail: 'Market data refreshed', time: '4h ago', icon: TrendingUp },
  { title: 'SG16 Children', detail: 'AI model optimized', time: '6h ago', icon: HeartPulse },
  { title: 'SG16 Student', detail: 'New users registered', time: '8h ago', icon: GraduationCap },
];

const GLOBAL_REACH = [
  { flag: '🇳🇱', country: 'Netherlands', share: '12.4%' },
  { flag: '🇺🇸', country: 'United States', share: '11.8%' },
  { flag: '🇬🇧', country: 'United Kingdom', share: '9.6%' },
  { flag: '🇯🇵', country: 'Japan', share: '6.8%' },
  { flag: '🇲🇾', country: 'Malaysia', share: '5.2%' },
  { flag: '🇩🇪', country: 'Germany', share: '4.9%' },
];

export function LandingPage() {
  const enterGuestTour = useAppStore((s) => s.enterGuestTour);
  const openStaging = useAppStore((s) => s.openStaging);
  const setWorkspace = useAppStore((s) => s.setWorkspace);

  return (
    <div className="landing-page relative min-h-[100dvh] overflow-x-hidden">
      {/* Global Clean Black × Neon Pink Cyber Backdrop */}
      <LandingVideoBg />

      <div className="landing-page__content relative z-[1]">
        <LandingHeader />

        {/* Hero Section with Cyber Portal & Dais */}
        <section className="landing-hero-section">
          <div className="landing-shell landing-hero-layout">
            <div className="landing-hero-panel">
              <p className="landing-hero-kicker">
                <span>SG16 AI ENGINE</span>
              </p>

              <h1 className="landing-hero-headline">
                <span className="landing-hero-headline-power">Most Powerful</span>
              </h1>

              <p className="landing-hero-sub">
                Sovereign Artificial Intelligence. Five distinct shields — chat, code, health, student, and market —
                built on foundational computing principles.
              </p>

              {/* CTAs matching reference dashboard */}
              <div className="landing-hero-cta">
                <button
                  type="button"
                  onClick={() => enterGuestTour()}
                  className="landing-btn-pink"
                >
                  <Rocket className="w-4 h-4 mr-2" />
                  <span>Start Tour</span>
                </button>
                <button
                  type="button"
                  onClick={() => openStaging()}
                  className="landing-btn-staging"
                >
                  <span className="w-2 h-2 rounded-full bg-[#38D9A9] animate-pulse mr-2 shadow-[0_0_8px_#38D9A9]" />
                  <span>Staging Lab (24/7 AI)</span>
                </button>
              </div>

              <p className="landing-hero-note">
                Engineered for privacy. Built for your control. SG16 AI Engine — your sovereign AI workspace.
              </p>
            </div>
          </div>

          {/* Flanking Live Threat & Market Intelligence Cards */}
          <LandingNetworkCards />
        </section>

        {/* ── Section: Our 5 Shields & Latest Activity ── */}
        <section id="features" className="landing-section">
          <div className="landing-shell">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* 5 Shields Card Collection (Spans 3 cols on desktop) */}
              <div className="lg:col-span-3 space-y-4">
                <div className="landing-panel">
                  <div className="flex items-center gap-2 mb-4">
                    <Shield className="w-4 h-4 text-[#FF168D]" />
                    <h2 className="text-base font-bold text-white font-['Orbitron',sans-serif]">Our 5 Shields</h2>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3.5">
                    {SHIELDS_DATA.map((item) => {
                      const Icon = item.icon;
                      return (
                        <div
                          key={item.id}
                          onClick={() => setWorkspace(item.id)}
                          className="group relative flex flex-col justify-between p-4 rounded-xl bg-gradient-to-b from-[#0F0C16] to-[#07070D] border border-[#29202F] hover:border-[#FF168D] shadow-md transition-all duration-200 cursor-pointer hover:-translate-y-1 hover:shadow-[0_0_20px_rgba(255,22,141,0.22)]"
                        >
                          <div>
                            <div className="w-9 h-9 rounded-lg bg-[#191321] border border-[#FF168D]/40 text-[#FF168D] flex items-center justify-center mb-3 shadow-[0_0_10px_rgba(255,22,141,0.2)]">
                              <Icon className="w-4 h-4" />
                            </div>
                            <h3 className="text-sm font-bold text-white group-hover:text-[#FF5CB8] transition-colors">
                              {item.title}
                            </h3>
                            <p className="mt-1 text-[11px] text-white/50 leading-relaxed line-clamp-3">
                              {item.desc}
                            </p>
                          </div>
                          <div className="mt-4 pt-2 border-t border-[#29202F] flex items-center text-[11px] font-bold text-[#FF168D] group-hover:text-[#FF3DA5]">
                            <span>Enter →</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Latest Activity Panel */}
              <div className="lg:col-span-1">
                <div className="landing-panel h-full flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-[#FF168D] shadow-[0_0_8px_#FF168D]" />
                        <h2 className="text-sm font-bold text-white font-['Orbitron',sans-serif]">Latest Activity</h2>
                      </div>
                      <ChevronRight className="w-4 h-4 text-white/40" />
                    </div>

                    <div className="space-y-3">
                      {LATEST_ACTIVITIES.map((act) => {
                        const Icon = act.icon;
                        return (
                          <div
                            key={act.title}
                            className="flex items-center gap-3 p-2 rounded-lg bg-[#0A0A12]/80 border border-[#29202F]/80 hover:border-[#60304F] transition"
                          >
                            <div className="w-7 h-7 rounded-md bg-[#191321] border border-[#FF168D]/30 text-[#FF168D] flex items-center justify-center shrink-0">
                              <Icon className="w-3.5 h-3.5" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="text-[12px] font-semibold text-white truncate">{act.title}</p>
                              <p className="text-[10px] text-white/50 truncate">{act.detail}</p>
                            </div>
                            <span className="text-[9px] font-mono text-white/40 shrink-0">{act.time}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ── Section: Projects, System Security & Global Reach ── */}
        <section className="landing-section pt-0">
          <div className="landing-shell">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Our Projects */}
              <div className="landing-panel flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4 text-[#FF168D]" />
                      <h2 className="text-sm font-bold text-white font-['Orbitron',sans-serif]">Our Projects</h2>
                    </div>
                    <span className="text-[10px] text-[#FF168D] font-semibold cursor-pointer hover:underline">
                      View All →
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2.5">
                    {[
                      { name: 'SG16 Engine', color: '#FF168D' },
                      { name: 'SG16 Finance', color: '#FF168D' },
                      { name: 'SG16 Children', color: '#FF168D' },
                      { name: 'SG16 Student', color: '#59A7FF' },
                      { name: 'SG16 Market', color: '#38D9A9' },
                    ].map((proj) => (
                      <span
                        key={proj.name}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0A0A12] border border-[#29202F] text-xs font-medium text-white/85"
                      >
                        <span className="w-2 h-2 rounded-full" style={{ backgroundColor: proj.color }} />
                        {proj.name}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-3 border-t border-[#29202F] flex items-center gap-2 text-[11px] text-white/50">
                  <Sparkles className="w-3.5 h-3.5 text-[#FF168D]" />
                  <span>One Platform • Multiple Solutions • Endless Possibilities</span>
                </div>
              </div>

              {/* System Security & 99.9% Platform Uptime */}
              <div className="landing-panel">
                <div className="flex items-center gap-2 mb-4">
                  <Shield className="w-4 h-4 text-[#FF168D]" />
                  <h2 className="text-sm font-bold text-white font-['Orbitron',sans-serif]">System Security</h2>
                </div>

                <div className="grid grid-cols-2 gap-4 items-center">
                  <div className="space-y-2 text-[11px] font-mono text-white/70">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Firewall</span>
                        <span className="text-[#38D9A9]">Active</span>
                      </div>
                      <div className="h-1.5 w-full bg-[#191321] rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-[#FF168D] to-[#FF5CB8] w-[95%]" />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Anti-DDoS</span>
                        <span className="text-[#38D9A9]">Protected</span>
                      </div>
                      <div className="h-1.5 w-full bg-[#191321] rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-[#FF168D] to-[#FF5CB8] w-[98%]" />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>Data Protection</span>
                        <span className="text-[#38D9A9]">Encrypted</span>
                      </div>
                      <div className="h-1.5 w-full bg-[#191321] rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-[#FF168D] to-[#FF5CB8] w-[100%]" />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span>AI Monitoring</span>
                        <span className="text-[#38D9A9]">24/7 Live</span>
                      </div>
                      <div className="h-1.5 w-full bg-[#191321] rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-[#FF168D] to-[#FF5CB8] w-[92%]" />
                      </div>
                    </div>
                  </div>

                  {/* Circular Uptime Gauge */}
                  <div className="flex flex-col items-center justify-center p-3 rounded-xl bg-[#0A0A12] border border-[#29202F]">
                    <span className="text-[10px] text-white/50 uppercase tracking-wider mb-1 font-mono">Platform Uptime</span>
                    <div className="relative flex items-center justify-center w-20 h-20 rounded-full border-2 border-[#FF168D] shadow-[0_0_18px_rgba(255,22,141,0.5)]">
                      <span className="text-sm font-bold text-white font-mono">99.9%</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Global Reach */}
              <div className="landing-panel">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-sm font-bold text-white font-['Orbitron',sans-serif]">Global Reach</h2>
                  <span className="text-[10px] font-mono text-[#FF5CB8]">120+ COUNTRIES</span>
                </div>

                <div className="space-y-1.5 text-xs font-mono">
                  {GLOBAL_REACH.map((item) => (
                    <div key={item.country} className="flex items-center justify-between text-white/75 py-0.5">
                      <span className="flex items-center gap-2">
                        <span>{item.flag}</span>
                        <span>{item.country}</span>
                      </span>
                      <span className="font-semibold text-white/90">{item.share}</span>
                    </div>
                  ))}
                  <div className="text-right pt-1">
                    <span className="text-[10px] text-[#FF168D] font-bold cursor-pointer hover:underline">+ More →</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ── Global Bottom Status Bar ── */}
        <footer className="border-t border-[#29202F] bg-[#050509] py-4 text-xs text-white/60">
          <div className="landing-shell flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Globe className="w-3.5 h-3.5 text-[#FF168D]" />
              <span>One Platform • Multiple Solutions • Endless Possibilities</span>
            </div>
            <div className="flex items-center gap-2 text-base">
              <span>🇺🇸</span>
              <span>🇬🇧</span>
              <span>🇫🇷</span>
              <span>🇷🇺</span>
              <span>🇨🇳</span>
              <span>🇩🇪</span>
            </div>
            <div>
              <span className="font-bold text-white">
                <span className="text-[#FF168D]">SG16 Engine</span> | Technology • Innovation • Global Impact
              </span>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
